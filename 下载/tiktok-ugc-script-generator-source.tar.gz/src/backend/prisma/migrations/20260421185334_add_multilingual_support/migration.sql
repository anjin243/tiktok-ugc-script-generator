-- AlterTable
ALTER TABLE "Project" ADD COLUMN     "aspectRatio" TEXT NOT NULL DEFAULT '9:16',
ADD COLUMN     "language" TEXT NOT NULL DEFAULT 'zh-CN',
ADD COLUMN     "referenceImages" TEXT[];
